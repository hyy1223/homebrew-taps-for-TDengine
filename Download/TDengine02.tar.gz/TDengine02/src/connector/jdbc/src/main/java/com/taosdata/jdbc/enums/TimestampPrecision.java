package com.taosdata.jdbc.enums;

public enum TimestampPrecision {
    MS,
    US,
    NS,
    UNKNOWN
}
