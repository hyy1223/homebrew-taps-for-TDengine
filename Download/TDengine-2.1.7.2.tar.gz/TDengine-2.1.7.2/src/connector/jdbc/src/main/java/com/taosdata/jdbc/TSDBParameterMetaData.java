package com.taosdata.jdbc;

public class TSDBParameterMetaData extends AbstractParameterMetaData {

    public TSDBParameterMetaData(Object[] parameters) {
        super(parameters);
    }
}
